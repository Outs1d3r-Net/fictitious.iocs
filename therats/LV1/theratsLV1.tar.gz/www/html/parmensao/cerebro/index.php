<?php
session_start();
?>
<html>
    <head>
	<link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans" rel="stylesheet"> 
	<link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
	<div class="menu">
	    <a href="index.php">Main Page</a>
	    <a href="upload.html">Upload Your Picture</a/>
	</div>
<?php

if(!isset($_GET['view']) || ($_GET['view']=="index.php")) {
   echo" <p><b>There are some secrets here !, Mouse stuff !</br></p>
    <img src='cerebro.jpg'>";
}
?>
    </body>
</html>
