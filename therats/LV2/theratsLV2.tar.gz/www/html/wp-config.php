<?php
/**
 * As configurações básicas do WordPress
 *
 * O script de criação wp-config.php usa esse arquivo durante a instalação.
 * Você não precisa usar o site, você pode copiar este arquivo
 * para "wp-config.php" e preencher os valores.
 *
 * Este arquivo contém as seguintes configurações:
 *
 * * Configurações do MySQL
 * * Chaves secretas
 * * Prefixo do banco de dados
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Configurações do MySQL - Você pode pegar estas informações com o serviço de hospedagem ** //
/** O nome do banco de dados do WordPress */
define( 'DB_NAME', 'lv426_wpdb' );

/** Usuário do banco de dados MySQL */
define( 'DB_USER', 'lv426_wpuser' );

/** Senha do banco de dados MySQL */
define( 'DB_PASSWORD', 'D4v2d@' );

/** Nome do host do MySQL */
define( 'DB_HOST', 'localhost' );

/** Charset do banco de dados a ser usado na criação das tabelas. */
define( 'DB_CHARSET', 'utf8mb4' );

/** O tipo de Collate do banco de dados. Não altere isso se tiver dúvidas. */
define( 'DB_COLLATE', '' );

/**#@+
 * Chaves únicas de autenticação e salts.
 *
 * Altere cada chave para um frase única!
 * Você pode gerá-las
 * usando o {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org
 * secret-key service}
 * Você pode alterá-las a qualquer momento para invalidar quaisquer
 * cookies existentes. Isto irá forçar todos os
 * usuários a fazerem login novamente.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'lzNc5r(t*3(GS:x-RRD?{ 8CJg`TS!|JWu;@rFKS4PWo#Hnkl/BxR`5GWUePH04u' );
define( 'SECURE_AUTH_KEY',  '{K?w^(ALfI2?R76x7Q:m1SazWj($K%q}q`)H?Xf^vH[E;N|Ne]L.@1+.kn0i`z[%' );
define( 'LOGGED_IN_KEY',    '.Ij7b6L#!U&sy5ZMU[)CsW&Yqw-mV%X<@5dh1eo8?,4h;-#}V+c@*OW(}nYoj8^d' );
define( 'NONCE_KEY',        '`QgGj?^+U{bEbr34+<x8 o!wTB/3M<mINoNbjDzeypLWU9JDjmcn7RbfjC,s4KQi' );
define( 'AUTH_SALT',        ';RfDT|*g}[tTrE;us!xp+?e.8*lx]wjmIZM{|e+TSXtTqCwH-g%+|PrvGHX,i,A?' );
define( 'SECURE_AUTH_SALT', 'RhCnZRBH:=D%YXEpD^,@|$XAQ>(^<&{[l |(!5$;IC;tI*xcXGx@Mf<qUYmY!v^J' );
define( 'LOGGED_IN_SALT',   'spPWw#h@}R8>84&!fT%@^^ z.RG&%bT!|yMqelCkw)}rc$`,P!DGh]Ns)J#%]2B5' );
define( 'NONCE_SALT',       'uAbY#UJmSr`PWk~Q5P3z`&WQ#UY)h;f=o0;DsP_q)gE p3h[f/(K1A_fwv!H>E2N' );

/**#@-*/

/**
 * Prefixo da tabela do banco de dados do WordPress.
 *
 * Você pode ter várias instalações em um único banco de dados se você der
 * um prefixo único para cada um. Somente números, letras e sublinhados!
 */
$table_prefix = 'wp_';

/**
 * Para desenvolvedores: Modo de debug do WordPress.
 *
 * Altere isto para true para ativar a exibição de avisos
 * durante o desenvolvimento. É altamente recomendável que os
 * desenvolvedores de plugins e temas usem o WP_DEBUG
 * em seus ambientes de desenvolvimento.
 *
 * Para informações sobre outras constantes que podem ser utilizadas
 * para depuração, visite o Codex.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Isto é tudo, pode parar de editar! :) */

/** Caminho absoluto para o diretório WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Configura as variáveis e arquivos do WordPress. */
require_once ABSPATH . 'wp-settings.php';
