<?php
/*
Your plugin must have a short description and a version number
*/

$plugin_description = 'Compare NMAP results to data stored in ONA.';
$plugin_version = '1.1';
$plugin_help_url = 'https://github.com/opennetadmin/ona/wiki/Plugin-ona-nmap-scans';

?>
