<?php
$modbodyhtml .= "<span style='font-size: xx-small;' title='Make sure the module \"{$modulename}\" is somewhere in {$base}/workspace_plugins/'><img src='{$images}/silk/exclamation.png' border='0' /> Unable to find module!</span>";
?>