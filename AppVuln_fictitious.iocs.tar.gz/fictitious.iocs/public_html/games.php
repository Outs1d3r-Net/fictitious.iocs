<!DOCTYPE html>
<html>
<head>
   <title>Intertainment Games</title>
</head>

<body>

<div align="center">

   <form method="GET" action="" name="form">
   <p>Your name:<input type="text" name="username"></p>
   <input type="submit" name="submit" value="Submit">
   </form>

</div>

<?php

if(isset($_GET["username"]))

	echo("Hello ".$_GET["username"]);
        echo "You is one master ! ";

?>

</body>

</html>
