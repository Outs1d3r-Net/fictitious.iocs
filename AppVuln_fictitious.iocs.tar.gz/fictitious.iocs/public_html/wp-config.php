<?php
/**
 * As configurações básicas do WordPress
 *
 * O script de criação wp-config.php usa esse arquivo durante a instalação.
 * Você não precisa usar o site, você pode copiar este arquivo
 * para "wp-config.php" e preencher os valores.
 *
 * Este arquivo contém as seguintes configurações:
 *
 * * Configurações do MySQL
 * * Chaves secretas
 * * Prefixo do banco de dados
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Configurações do MySQL - Você pode pegar estas informações com o serviço de hospedagem ** //
/** O nome do banco de dados do WordPress */
define( 'DB_NAME', 'iocs' );

/** Usuário do banco de dados MySQL */
define( 'DB_USER', 'admin' );

/** Senha do banco de dados MySQL */
define( 'DB_PASSWORD', 'break4me' );

/** Nome do host do MySQL */
define( 'DB_HOST', 'localhost' );

/** Charset do banco de dados a ser usado na criação das tabelas. */
define( 'DB_CHARSET', 'utf8mb4' );

/** O tipo de Collate do banco de dados. Não altere isso se tiver dúvidas. */
define( 'DB_COLLATE', '' );

/**#@+
 * Chaves únicas de autenticação e salts.
 *
 * Altere cada chave para um frase única!
 * Você pode gerá-las
 * usando o {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org
 * secret-key service}
 * Você pode alterá-las a qualquer momento para invalidar quaisquer
 * cookies existentes. Isto irá forçar todos os
 * usuários a fazerem login novamente.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'L;1DRAf-W]OQ-_ ^kmC.TfZu$-lc3,.F)Wc<2Xw0gRngN2iHt+yZ!=7OIbxu[.~2' );
define( 'SECURE_AUTH_KEY',  '/hQU6N=xx^/f#^f!qO#iD@`JWJ,^f4[IaOOVu]Fn}`xxJgsoZg4B}$aQW8:Pyal}' );
define( 'LOGGED_IN_KEY',    'u!iU=+6#?byo7`%yAH:rI(_^?P.HxYOrGm~5Mj@s4.HrMZ=PBa[Xso23;L3aed^U' );
define( 'NONCE_KEY',        'c{.wpGeIP,Bpp8+3FE3S&[3/`;tkf46qzzR^w=}O-%DUwyQ!+Bh6&G3GVk~+Jt~Q' );
define( 'AUTH_SALT',        'Y]31!t;w3!.G6d<m#Kc<@/D[Y+2%Op,I]a@(g#wf{1dYs4 d5IM3`o`[%)=.p~bF' );
define( 'SECURE_AUTH_SALT', 'mvH>-pFX?Tuz9`,(Sb<0+E9hg<HQu6.=REuq O45X){bH+*|mRvzr2?@:Z;AgX;X' );
define( 'LOGGED_IN_SALT',   '^os;c[67|D?Ahc0!ai-/kl#iuOA3>{W%B-LxA6)}-hp!Xv~2^N:V1D6S4xs8A(gM' );
define( 'NONCE_SALT',       'JY=7rSD(V3w]-<|Y@xg.I)K%C&h}z+*k!=X[$ ZJ#;ekk9Bb_`W1yssGL+bhBJ$~' );

/**#@-*/

/**
 * Prefixo da tabela do banco de dados do WordPress.
 *
 * Você pode ter várias instalações em um único banco de dados se você der
 * um prefixo único para cada um. Somente números, letras e sublinhados!
 */
$table_prefix = 'wp_';

/**
 * Para desenvolvedores: Modo de debug do WordPress.
 *
 * Altere isto para true para ativar a exibição de avisos
 * durante o desenvolvimento. É altamente recomendável que os
 * desenvolvedores de plugins e temas usem o WP_DEBUG
 * em seus ambientes de desenvolvimento.
 *
 * Para informações sobre outras constantes que podem ser utilizadas
 * para depuração, visite o Codex.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Isto é tudo, pode parar de editar! :) */

/** Caminho absoluto para o diretório WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Configura as variáveis e arquivos do WordPress. */
require_once ABSPATH . 'wp-settings.php';
