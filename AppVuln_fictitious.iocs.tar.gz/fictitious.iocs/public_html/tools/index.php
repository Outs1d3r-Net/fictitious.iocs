<html>
  <head>
    <title>Dns Tools</title>
  </head>
  <body>
    <!-- <div style="background-color:#afafaf;padding:15px;border-radius:20px 20px 0px 0px">
    </div> -->
    <div align="center" style="background-color:#498BFF;padding:20px;">
      <h1 align="center">Whois Online</h1>
    <form align="center" action="index.php" method="$_GET">
      <label align="center">Domain: </label>
      <input align="center" type="text" name="dns" value=""><br>
      <input align="center" type="submit" value="Consult">
    </form>
  </div>
  <div style="background-color:#C1C1C1;padding:20px;border-radius:0px 0px 20px 20px" align="center">
    <?php
    if(isset($_GET["dns"])){
      $target =$_GET["dns"];
      $substitutions = array('&&' => '',';'  => '','/' => '','\\' => '' );
      $target = str_replace(array_keys($substitutions),$substitutions,$target);
      echo '<pre>'.shell_exec('whois ' . $target).'</pre>';
      if($_GET["dns"] == "Trochilidae")
        echo "WHOIS";
    }

    ?>
  </div>
  </body>
</html>
