<?php
$servidor = "localhost";
$user = "admin";
$pass = "break4me";
$conn = mysqli_connect($servidor, $user, $pass);
$banco = mysqli_select_db($conn, iocs3);

$users = $_GET['user'];
$password = $_GET['pass'];

$sql = "SELECT * from login WHERE usuario = '$users' AND senha = '$password';";

$query = mysqli_query($conn, $sql);

if (mysqli_num_rows($query)==1)
{
	header("location:admin.php");
}
else
{
	echo "Usuario $users e/ou senha inválido(s).";
}
?>
